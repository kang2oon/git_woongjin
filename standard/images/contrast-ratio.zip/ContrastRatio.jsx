﻿try {  
    var colorpicker = new Object;    
    
 var w = new Window ("dialog");
var e1 = w.add ("edittext", undefined, "1");
var e2 = w.add ("edittext", undefined, "1"); e1.characters = e2.characters = 3; e1.active = true;
function handle_key (event) {
   var step;
   ScriptUI.environment.keyboardState['shiftKey'] ? step = 10 : step = 1;
   if(event.keyName == 'Minus'){
      this.text = Number(this.text)-step;
      event.preventDefault();
   }
   if(event.keyName == 'Equal'){
      this.text = Number(this.text)+step;
      event.preventDefault();
   }
}
e1.addEventListener ("keydown", handle_key );
e2.addEventListener ("keydown",  handle_key );
   
w.show();
    
    colorpicker.setForeground = function (color){
        app.foregroundColor = colorpicker.translateColor(color);
    }

    colorpicker.setBackground = function (color){
        app.backgroundColor = colorpicker.translateColor(color);
    }
    
    colorpicker.debug = function(str){
        alert(str);
    }

    colorpicker.getForeground = function (){
        xml = "<object>";
        xml += colorpicker.convertToXML(app.foregroundColor.rgb.hexValue.toString(), "foreground");
        xml += "</object>"
        return xml;
    }

    colorpicker.getBackground = function (){
        xml = "<object>";
        xml += colorpicker.convertToXML(app.backgroundColor.rgb.hexValue.toString(), "background");
        xml += "</object>"
        return xml;
    }
	
    colorpicker.getFont = function(){
        xml = "<object>";
        xml += colorpicker.convertToXML(app.activeDocument.activeLayer.textItem.size.toString(), "size");
        xml += colorpicker.convertToXML(app.activeDocument.activeLayer.textItem.color.rgb.hexValue.toString(), "color");
        xml += colorpicker.convertToXML(app.activeDocument.activeLayer.textItem.fauxBold, "bold");
        xml += colorpicker.convertToXML(app.activeDocument.activeLayer.textItem.contents, "content");
        xml += "</object>"
        return xml;
    }
   
    colorpicker.translateColor = function (c){
        var color = new SolidColor;
        color.rgb.red 	= (c >> 16) & 0xFF;
        color.rgb.green = (c >> 8) & 0xFF;
        color.rgb.blue 	= c & 0xFF;
        return color;
    }
	
	colorpicker.convertToXML = function (property, identifier){
		var type = typeof property;
		var xml = '<property id = "' + identifier + '" >';
		
		switch(type){
			case "number":
				xml += "<number>";
				xml += property.toString();
				xml += "</number>";
				break;
			case "boolean":
				xml += "<" + property.toString() + "/>";
				break;
			case "string":
				xml += "<string>";
				xml += property.toString();
				xml += "</string>";
				break;
			case "object":
				// Object case is currently not supported
				alert("Object case is currently not supported");
				//xml += "<object>";
				//for(var i in property)
				//	xml += convertToXML(property[i], 
				//xml += "</object>";
				break;
			case "undefined":
				xml += "<string>undefined</string>";
				break;
			default:
				alert("Type " + type + " is unknown.");
				return "";
		}
		xml += '</property>';
		return xml;
	}
	
	colorpicker.getVersion = function () {
		xml = "<object>";
		xml += colorpicker.convertToXML(app.version, "version");
		xml += "</object>"
		return xml;
	}
	
	colorpicker.getAppBitMode = function () {
		var appBitMode = 32;
		try { 
			var ref = new ActionReference();
			ref.putProperty( charIDToTypeID( 'Prpr' ), charIDToTypeID( 'Sz  ' ) );
			ref.putEnumerated( charIDToTypeID( 'capp' ),  charIDToTypeID( 'Ordn' ), charIDToTypeID( 'Trgt' ) );
			var desc = executeActionGet( ref );
			appBitMode = desc.getDouble( charIDToTypeID( 'Sz  ' ) );
		}
		catch(e) {
			// older versions like CS4 will not have this key
			// running this on CS4 in 64 bit mode will be wrong for example
		}
		xml = "<object>";
		xml += colorpicker.convertToXML(appBitMode, "appBitMode");
		xml += "</object>"
		return xml;
	}
	
	/*
	 * "getCR" Code is N-WAX(NHN Web Accessibility eXtension).
	 * Portions created by the Initial Developer are Copyright (C) 2011
	 * the Initial Developer. All Rights Reserved.
	*/	
	colorpicker.getCR = function(color) {
		color = color.split(',');
		var color1 = color[0];
		var color2 = color[1];
		var l1; // higher value
		var l2; // lower value
		var contrast;
		var l1R, l1G, l1B, l2R, l2G, l2B;
		// error check, check if pound sign was put in field value
		if (color2.indexOf('#') == 0) {
			color2 = color2.substr(1, color2.length-1);
		}
		if (color1.indexOf('#') == 0) {
			color1 = color1.substr(1, color1.length-1);
		}
	
		//Linearised R (for example) = (R/FS)^2.2 where FS is full scale value (255
		//for 8 bit color channels). L1 is the higher value (of text or background)
		//alert(parseInt("0x"+color1.substr(0,2)));
		//Math.pow(n,x);
		l1R = parseInt("0x"+color1.substr(0,2))/255;
		if (l1R <= 0.03928) {
			l1R = l1R/12.92;
		} else {
			l1R = Math.pow(((l1R+0.055)/1.055),2.4);
		}
		l1G = parseInt("0x"+color1.substr(2,2))/255;
		if (l1G <= 0.03928) {
			l1G = l1G/12.92;
		} else {
			l1G = Math.pow(((l1G+0.055)/1.055),2.4);
		}
		l1B = parseInt("0x"+color1.substr(4,2))/255;
		if (l1B <= 0.03928) {
			l1B = l1B/12.92;
		} else {
			l1B = Math.pow(((l1B+0.055)/1.055),2.4);
		}
		l2R = parseInt("0x"+color2.substr(0,2))/255;
		if (l2R <= 0.03928) {
			l2R = l2R/12.92;
		} else {
			l2R = Math.pow(((l2R+0.055)/1.055),2.4);
		}
		l2G = parseInt("0x"+color2.substr(2,2))/255;
		if (l2G <= 0.03928) {
			l2G = l2G/12.92;
		} else {
			l2G = Math.pow(((l2G+0.055)/1.055),2.4);
		}
		l2B = parseInt("0x"+color2.substr(4,2))/255;
		if (l2B <= 0.03928) {
			l2B = l2B/12.92;
		} else {
			l2B = Math.pow(((l2B+0.055)/1.055),2.4);
		}
		//where L is luminosity and is defined as
		l1 = (.2126*l1R) + (.7152*l1G) + (.0722*l1B); //using linearised R, G, and B value
		l2 = (.2126*l2R) + (.7152*l2G) + (.0722*l2B); //using linearised R, G, and B value
		//and L2 is the lower value.
		l1 = l1 + .05;
		l2 = l2 + .05;
		if (l1 < l2) {
		  temp = l1;
		  l1 = l2;
		  l2 = temp;
		}
		l1 = l1/l2;
		l1 = l1.toFixed(1);
		
		xml = "<object>";
		xml += colorpicker.convertToXML(l1, "ratio");
		xml += "</object>"
		return xml;
	}
}
catch(e) {
	alert("ColorPicker error: " + e + " : " + e.line);
}